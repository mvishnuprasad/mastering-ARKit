//
//  ARView+Extensions.swift
//  FurnitureStore
//
//  Created by Mohammad Azam on 6/7/22.
//

import Foundation
import RealityKit
import ARKit

extension ARView {
    
    func addCoachingOverlay() {
        
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        coachingOverlay.goal = .horizontalPlane
        coachingOverlay.session = self.session
        self.addSubview(coachingOverlay)
        
    }
    
}
