//
//  ViewController.swift
//  HelloARKit
//
//  Created by Mohammad Azam on 10/19/17.
//  Copyright © 2017 Mohammad Azam. All rights reserved.
//

import UIKit
//import SceneKit
import ARKit

class ViewController: UIViewController, ARSCNViewDelegate {

    @IBOutlet var sceneView: ARSCNView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let string = SCNText(string: "Hello", extrusionDepth: 1.0)
        string.firstMaterial?.diffuse.contents = UIColor.blue
        let textNode = SCNNode(geometry: string)
        textNode.position=SCNVector3(0, 0,-0.5)
        textNode.scale=SCNVector3(0.02, 0.2, 0.02)
        
        let box = SCNBox(width: 0.3, height: 0.3, length: 0.2, chamferRadius: 0)
        let material = SCNMaterial()
        material.diffuse.contents=UIColor.red
        box.materials=[material]
        let boxNode = SCNNode(geometry: box)
        boxNode.position=SCNVector3(0, 0, -1)
        self.sceneView.scene.rootNode.addChildNode(boxNode)

        self.sceneView.scene.rootNode.addChildNode(textNode)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()

        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    // MARK: - ARSCNViewDelegate
    
/*
    // Override to create and configure nodes for anchors added to the view's session.
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let node = SCNNode()
     
        return node
    }
*/
    

}
